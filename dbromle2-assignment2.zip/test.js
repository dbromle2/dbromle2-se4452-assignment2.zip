var foo = require("./purchaseOrderF20-fixed");

var assert = require("assert");
var sinon = require("sinon");

//test
// describe("Array", function() {
//     describe("#indexOf()", function(){
//         it("should return -1 when value is not present", function(){
//             assert.strictEqual("abcd", "abcd");
//         });
//     });
// });

/*---------------------------------------------------------*/
/*--------------- EQUIVALENCE CLASS TESTING ---------------*/
/*---------------------------------------------------------*/
describe("EQUIVALENCE CLASS TESTING", function () {
    //F1 getAgeFactor
    describe("F1 getAgeFactor", function () {
        var age = [
            { in: 15, exp: 0 },
            { in: 20, exp: 10 },
            { in: 30, exp: 15 },
            { in: 40, exp: 20 },
            { in: 50, exp: 45 },
            { in: 70, exp: 25 },
            { in: 100, exp: 0 },
        ];

        age.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in, function () {
                var myVar = {}
                myVar.age = test.in;
                var myResult = foo.getAgeFactor(myVar);
                assert.strictEqual(myResult, test.exp)
            });
        });
    });

    //F2 getBalanceFactor
    describe("F2 getBalanceFactor", function () {
        var balance = [
            { in: 0, exp: 0 },
            { in: 90, exp: 5 },
            { in: 300, exp: 15 },
            { in: 750, exp: 25 },
            { in: 2000, exp: 65 },
            { in: 4000, exp: 150 },
            { in: 6000, exp: 0 },
        ];

        balance.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in, function () {
                var myVar = {}
                myVar.balance = test.in;
                var myResult = foo.getBalanceFactor(myVar);
                assert.strictEqual(myResult, test.exp)
            });
        });
    });

    //F3 accountStatus
    describe("F3 accountStatus", function () {
        var balance = [
            { in: 0, exp: "invalid" },
            { in: 100, exp: "adverse" },
            { in: 300, exp: "acceptable" },
            { in: 750, exp: "good" },
            { in: 2000, exp: "excellent" },
        ];

        balance.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in, function () {
                //use stubs to spoof the ageFactor and balanceFactor values
                var stub1 = sinon.stub(foo, "getAgeFactor");
                stub1.returns(1); //use "1" for easy multiplication
                var stub2 = sinon.stub(foo, "getBalanceFactor");
                stub2.returns(test.in);
                var myResult = foo.accountStatus(null);
                stub1.restore();
                stub2.restore();
                assert.strictEqual(myResult, test.exp);

            });
        });
    });

    //F4 creditStatus
    describe("F4 creditStatus", function () {
        var ins = [
            { in: -1, in2: "restricted", exp: "invalid" },
            { in: 60, in2: "restricted", exp: "adverse" },
            { in: 70, in2: "restricted", exp: "good" },
            { in: 70, in2: "default", exp: "adverse" },
            { in: 90, in2: "default", exp: "good" },
            { in: 150, in2: "default", exp: "invalid" },
        ];

        ins.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in + " and " + test.in2, function () {
                var myVar = {}
                myVar.creditScore = test.in;
                var myResult = foo.creditStatus(myVar, test.in2);
                assert.strictEqual(myResult, test.exp);
            });
        });
    });

    //F5 productStatus and names match
    describe("F5 productStatus - names match", function () {
        var ins = [
            { in: 0, in2: 500, exp: "soldout" },
            { in: 60, in2: 500, exp: "limited" },
            { in: 500, in2: 500, exp: "available" },
            { in: 900, in2: 500, exp: "available" },
        ];

        ins.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in + " and " + test.in2, function () {
                var myVar = [];
                var product = "a";
                var inv = {};
                inv.name = "a";
                inv.q = test.in;
                myVar.push(inv);
                var myResult = foo.productStatus(product, myVar, test.in2);
                assert.strictEqual(myResult, test.exp);

            });
        });
    });

    //F5 productStatus but names mismatch
    describe("F5 productStatus - names mismatch", function () {
        var ins = [
            { in: 0, in2: 500, exp: "invalid" },
            { in: 60, in2: 500, exp: "invalid" },
            { in: 500, in2: 500, exp: "invalid" },
            { in: 900, in2: 500, exp: "invalid" },
        ];

        ins.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in + " and " + test.in2, function () {
                var myVar = [];
                var product = "b";
                var inv = {};
                inv.name = "a";
                inv.q = test.in;
                myVar.push(inv);
                var myResult = foo.productStatus(product, myVar, test.in2);
                assert.strictEqual(myResult, test.exp);

            });
        });
    });
});

/*---------------------------------------------------------*/
/*--------------- BOUNDARY VALUE TESTING ---------------*/
/*---------------------------------------------------------*/
describe("BOUNDARY VALUE TESTING", function () {
    //F1 getAgeFactor
    describe("F1 getAgeFactor", function () {
        var age = [
            { in: 17, exp: 0 },
            { in: 18, exp: 10 },
            { in: 19, exp: 10 },
            { in: 24, exp: 10 },
            { in: 25, exp: 15 },
            { in: 26, exp: 15 },
            { in: 34, exp: 15 },
            { in: 35, exp: 20 },
            { in: 36, exp: 20 },
            { in: 44, exp: 20 },
            { in: 45, exp: 45 },
            { in: 46, exp: 45 },
            { in: 64, exp: 45 },
            { in: 65, exp: 25 },
            { in: 66, exp: 25 },
            { in: 94, exp: 25 },
            { in: 95, exp: 0 },
            { in: 96, exp: 0 },
        ];

        age.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in, function () {
                var myVar = {}
                myVar.age = test.in;
                var myResult = foo.getAgeFactor(myVar);
                assert.strictEqual(myResult, test.exp)
            });
        });
    });

    //F2 getBalanceFactor
    describe("F2 getBalanceFactor", function () {
        var balance = [
            { in: -1, exp: 0 },
            { in: 0, exp: 0 },
            { in: 1, exp: 5 },
            { in: 99, exp: 5 },
            { in: 100, exp: 15 },
            { in: 101, exp: 15 },
            { in: 499, exp: 15 },
            { in: 500, exp: 25 },
            { in: 501, exp: 25 },
            { in: 999, exp: 25 },
            { in: 1000, exp: 65 },
            { in: 1001, exp: 65 },
            { in: 2999, exp: 65 },
            { in: 3000, exp: 150 },
            { in: 3001, exp: 150 },
            { in: 4999, exp: 150 },
            { in: 5000, exp: 0 },
            { in: 5001, exp: 0 },
        ];

        balance.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in, function () {
                var myVar = {}
                myVar.balance = test.in;
                var myResult = foo.getBalanceFactor(myVar);
                assert.strictEqual(myResult, test.exp)
            });
        });
    });

    //F3 accountStatus
    describe("F3 accountStatus", function () {
        var balance = [
            { in: -1, exp: "invalid" },
            { in: 0, exp: "invalid" },
            { in: 1, exp: "adverse" },
            { in: 149, exp: "adverse" },
            { in: 150, exp: "acceptable" },
            { in: 151, exp: "acceptable" },
            { in: 599, exp: "acceptable" },
            { in: 600, exp: "good" },
            { in: 601, exp: "good" },
            { in: 999, exp: "good" },
            { in: 1000, exp: "excellent" },
            { in: 1001, exp: "excellent" },
        ];

        balance.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in, function () {
                //use stubs to spoof the ageFactor and balanceFactor values
                var stub1 = sinon.stub(foo, "getAgeFactor");
                stub1.returns(1); //use "1" for easy multiplication
                var stub2 = sinon.stub(foo, "getBalanceFactor");
                stub2.returns(test.in);
                var myResult = foo.accountStatus(null);
                stub1.restore();
                stub2.restore();
                assert.strictEqual(myResult, test.exp);

            });
        });
    });

    //F4 creditStatus
    describe("F4 creditStatus", function () {
        var ins = [
            { in: 0, in2: "default", exp: "adverse" },
            { in: 1, in2: "default", exp: "adverse" },
            { in: 64, in2: "restricted", exp: "adverse" },
            { in: 65, in2: "restricted", exp: "good" },
            { in: 66, in2: "restricted", exp: "good" },
            { in: 74, in2: "default", exp: "adverse" },
            { in: 75, in2: "default", exp: "good" },
            { in: 76, in2: "default", exp: "good" },
            { in: 99, in2: "default", exp: "good" },
            { in: 100, in2: "default", exp: "good" },
        ];

        ins.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in + " and " + test.in2, function () {
                // var stub1 = sinon.stub(foo, "getAgeFactor");
                // stub1.returns(1);
                // var stub2 = sinon.stub(foo, "getBalanceFactor");
                // stub2.returns(foo.in);
                var myVar = {}
                myVar.creditScore = test.in;
                var myResult = foo.creditStatus(myVar, test.in2);
                // stub1.restore();
                // stub2.restore();
                assert.strictEqual(myResult, test.exp);

            });
        });
    });

    //F5 productStatus and names match
    describe("F5 productStatus", function () {
        var ins = [
            { in: 0, in2: 500, exp: "soldout" },
            { in: 1, in2: 500, exp: "limited" },
            { in: 499, in2: 500, exp: "limited" },
            { in: 500, in2: 500, exp: "available" },
            { in: 501, in2: 500, exp: "available" },
            { in: 999, in2: 500, exp: "available" },
            { in: 1000, in2: 500, exp: "available" },
        ];

        ins.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in + " and " + test.in2, function () {
                var myVar = [];
                var product = "a";
                var inv = {};
                inv.name = "a";
                inv.q = test.in;
                myVar.push(inv);
                var myResult = foo.productStatus(product, myVar, test.in2);
                assert.strictEqual(myResult, test.exp);

            });
        });
    });
});

/*---------------------------------------------------------*/
/*--------------- DECISION TABLE TESTING ---------------*/
/*---------------------------------------------------------*/
describe("DECISION TABLE TESTING", function () {
    //F6 orderHandling
    describe("F6 orderHandling", function () {
        var ins = [
            { in: "excellent", in2: "", in3: "", exp: "accepted" },
            { in: "good", in2: "good", in3: "", exp: "accepted" },
            { in: "acceptable", in2: "good", in3: "available", exp: "accepted" },
            { in: "adverse", in2: "good", in3: "available", exp: "accepted" },
            { in: "acceptable", in2: "good", in3: "limited", exp: "pending" },
            { in: "acceptable", in2: "good", in3: "soldout", exp: "pending" },
            { in: "adverse", in2: "good", in3: "limited", exp: "pending" },
            { in: "good", in2: "adverse", in3: "", exp: "underReview" },
            { in: "acceptable", in2: "adverse", in3: "available", exp: "underReview" },
            { in: "invalid", in2: "", in3: "", exp: "rejected" },
            { in: "", in2: "invalid", in3: "", exp: "rejected" },
            { in: "", in2: "", in3: "invalid", exp: "rejected" },
            { in: "acceptable", in2: "adverse", in3: "limited", exp: "rejected" },
            { in: "acceptable", in2: "adverse", in3: "soldout", exp: "rejected" },
            { in: "adverse", in2: "good", in3: "soldout", exp: "rejected" },
            { in: "adverse", in2: "adverse", in3: "", exp: "rejected" },
        ];

        ins.forEach(function (test) {
            it("expected: " + test.exp + " from input: " + test.in + " and " + test.in2 + " and " + test.in3, function () {
                var stub1 = sinon.stub(foo, "accountStatus");
                stub1.returns(test.in);
                var stub2 = sinon.stub(foo, "creditStatus");
                stub2.returns(test.in2);
                var stub3 = sinon.stub(foo, "productStatus");
                stub3.returns(test.in3);
                var myVar = {}
                myVar.ins = test.in;
                var myResult = foo.orderHandling(myVar);
                stub1.restore();
                stub2.restore();
                stub3.restore();
                assert.strictEqual(myResult, test.exp);

            });
        });
    });
})